# SPORTZONE — 9 telas em Angular 17

Projeto Integrador II · Grupo 6 · Centro Universitário Senac (ADS) · Prof. Dr. Eliseu Lemes da Silva

Loja virtual de artigos esportivos com foco em futebol. Esta versão implementa em **Angular 17 (NgModules)** as **9 telas** do projeto,
usando TypeScript, HTML e CSS, com os mesmos nomes e a mesma numeração da ficha de prototipagem.

## As 9 telas

| Nº | Tela | Rota | Onde está |
|---|---|---|---|
| 1 | Login | `/login` | `src/app/login/` (LoginModule) |
| 2 | Cadastro de usuário | `/registro` | `src/app/registro/` (RegistroModule) |
| 3 | Página inicial | `/` | `src/app/pages/home/` (módulo principal) |
| 4 | Catálogo de produtos | `/catalogo` | `src/app/catalogo/` (CatalogoModule) |
| 5 | Detalhes do produto | `/produto/:id` | `src/app/produto/` (ProdutoModule) |
| 6 | Carrinho de compras | `/carrinho` | `src/app/carrinho/` (CarrinhoModule) |
| 7 | Área administrativa | `/admin` | `src/app/admin/painel/` (AdminModule) |
| 8 | Gerenciamento de produtos | `/admin/produtos` | `src/app/admin/produtos/` (AdminModule) |
| 9 | Cadastro e edição de produtos | `/admin/produtos/novo` e `/admin/produtos/editar/:id` | `src/app/admin/produto-form/` (AdminModule) |

O módulo principal (`app.module.ts`) traz cabeçalho, rodapé e a Página inicial; as demais telas são módulos carregados sob demanda
(lazy loading) em `app-routing.module.ts`. As telas 7, 8 e 9 ficam atrás de uma guarda de rota (`core/guards/admin.guard.ts`).

## Como executar no Windows com o VS Code

1. Instale o **Node.js 18.13+ ou 20 LTS** (https://nodejs.org). Node 22 também funciona; o Angular 17 pode mostrar um aviso de versão.
2. No VS Code: *File → Open Folder…* e escolha a pasta `sportzone` (a que contém `package.json`).
3. Abra o terminal integrado (*Terminal → New Terminal*) e confira: `node -v` e `npm -v`.
4. Instale as dependências (só na primeira vez): `npm install`
5. Inicie: `npm start`
6. Abra **http://localhost:4200** no navegador. Para parar: `Ctrl + C`.

Build de produção (opcional): `npm run build`.

**Erros comuns:** `ng` não reconhecido → use `npm start`; porta 4200 ocupada → `npx ng serve --port 4300`;
erros estranhos → apague `node_modules` e rode `npm install`; PowerShell bloqueando scripts →
`Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` ou use o Prompt de Comando.

## Como testar (contas de demonstração)

| Perfil | E-mail | Senha |
|---|---|---|
| Cliente | `demo@sportzone.com` | `Demo@1234` |
| Administrador | `admin@sportzone.com` | `Admin@1234` |

(Na tela de Login há botões que preenchem essas contas.)

- **Cliente:** pesquise e filtre no catálogo, abra um produto, escolha tamanho/quantidade, adicione ao carrinho, ajuste quantidades no carrinho.
- **Cadastro:** nome e sobrenome, e-mail válido, senha com 8+ caracteres (letras e números), confirmação igual e aceite do aviso.
- **Administração:** o item **Administração** do menu pede login de administrador (cliente comum é barrado). No painel, veja indicadores e alertas;
  em *Produtos*, atualize preço/estoque, edite ou exclua; em *Novo produto*, cadastre com pré-visualização. As alterações aparecem na loja.

## Estrutura de arquivos

```
src/app/
├─ app.module.ts, app-routing.module.ts, app.component.ts   módulo principal e rotas das 9 telas
├─ core/models/produto.ts            interfaces (Produto, ItemCarrinho, Usuario, Sessao…)
├─ core/services/produtos.service.ts catálogo com criar/atualizar/excluir (localStorage)
├─ core/services/carrinho.service.ts carrinho (id, tamanho, quantidade; preço e estoque vêm do catálogo)
├─ core/services/auth.service.ts     login/cadastro demonstrativos, perfil cliente/admin
├─ core/services/aviso.service.ts    mensagens de feedback (toast)
├─ core/guards/admin.guard.ts        protege /admin
├─ shared/                           cabeçalho, rodapé, SharedModule, card de produto, aviso
├─ pages/home/                       Tela 3
├─ login/  registro/                 Telas 1 e 2
├─ catalogo/  produto/  carrinho/    Telas 4, 5 e 6
└─ admin/                            Telas 7, 8 e 9 (shell, painel, produtos, produto-form)
```

## Limitações (importante para a apresentação)

- **Não há back-end nem banco de dados nesta etapa.** Produtos, usuários, carrinho e sessão ficam no `localStorage` do navegador
  (limpar os dados do site restaura o estado inicial). Os produtos, preços e imagens são fictícios.
- **Login e área administrativa são demonstrativos e NÃO são seguros**: o perfil de administrador e a guarda de rota existem apenas para
  demonstrar o fluxo e podem ser contornados no navegador. A senha é guardada só como hash SHA-256 local. Serão substituídos por autenticação no servidor.
- O botão **Finalizar compra** apenas exibe um aviso: pagamento e pedidos dependem do back-end (etapas futuras).
- O protótipo visual em HTML (arquivo `SPORTZONE_Prototipo.html`) é um material à parte e não faz parte do código Angular.
