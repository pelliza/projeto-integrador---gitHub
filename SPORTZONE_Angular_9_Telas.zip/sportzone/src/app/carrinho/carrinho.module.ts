import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { CarrinhoComponent } from './carrinho.component';

const routes: Routes = [{ path: '', component: CarrinhoComponent, title: 'SPORTZONE | Carrinho' }];

/** TELA 6 — Carrinho de compras (rota /carrinho, carregada sob demanda). */
@NgModule({
  declarations: [CarrinhoComponent],
  imports: [SharedModule, RouterModule.forChild(routes)]
})
export class CarrinhoModule {}
