import { Component } from '@angular/core';
import { combineLatest, map } from 'rxjs';
import { ItemCarrinho } from '../core/models/produto';
import { AvisoService } from '../core/services/aviso.service';
import { CarrinhoService, FRETE_GRATIS_A_PARTIR_DE } from '../core/services/carrinho.service';

/** TELA 6 — Carrinho de compras: conferir, ajustar e remover itens, com resumo do pedido. */
@Component({
  selector: 'app-carrinho',
  templateUrl: './carrinho.component.html',
  styleUrls: ['./carrinho.component.css']
})
export class CarrinhoComponent {
  freteGratisAPartirDe = FRETE_GRATIS_A_PARTIR_DE;
  vm$ = combineLatest([this.carrinho.itens$, this.carrinho.quantidadeTotal$, this.carrinho.subtotal$, this.carrinho.frete$, this.carrinho.total$]).pipe(
    map(([itens, quantidade, subtotal, frete, total]) => ({ itens, quantidade, subtotal, frete, total }))
  );

  constructor(private carrinho: CarrinhoService, private aviso: AvisoService) {}

  aumentar(i: ItemCarrinho): void { this.carrinho.alterarQuantidade(i, 1); }
  diminuir(i: ItemCarrinho): void { this.carrinho.alterarQuantidade(i, -1); }
  remover(i: ItemCarrinho): void { this.carrinho.remover(i); this.aviso.mostrar(`“${i.produto.nome}” foi removido do carrinho.`); }
  limpar(): void { this.carrinho.limpar(); this.aviso.mostrar('Carrinho esvaziado.'); }
  finalizar(): void {
    this.aviso.mostrar('Finalização de compra: etapa futura do projeto (ainda sem back-end).');
  }
  chave(_i: number, item: ItemCarrinho): string { return `${item.id}|${item.tamanho}`; }
}
