import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Perfil, Sessao, Usuario } from '../models/produto';

const CHAVE_USUARIOS = 'sz_usuarios';
const CHAVE_SESSAO = 'sz_sessao';

/**
 * Autenticação DEMONSTRATIVA.
 * Não existe servidor: os usuários ficam no localStorage do navegador e a senha é
 * guardada como hash SHA-256 apenas para não aparecer em texto puro. Isto NÃO é um
 * sistema de autenticação seguro: o controle de acesso da área administrativa existe
 * só para demonstrar o fluxo e será substituído por autenticação no servidor.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly sessao$ = new BehaviorSubject<Sessao | null>(this.lerSessao());
  readonly sessao = this.sessao$.asObservable();

  /** Contas de demonstração para testar sem cadastrar. */
  readonly contaDemo = { email: 'demo@sportzone.com', senha: 'Demo@1234' };
  readonly contaAdmin = { email: 'admin@sportzone.com', senha: 'Admin@1234' };

  get sessaoAtual(): Sessao | null { return this.sessao$.value; }
  get ehAdmin(): boolean { return this.sessao$.value?.perfil === 'admin'; }

  async cadastrar(nome: string, email: string, senha: string): Promise<{ ok: boolean; erro?: string }> {
    await this.garantirContasDemo();
    const usuarios = this.lerUsuarios();
    const emailNormalizado = email.trim().toLowerCase();
    if (usuarios.some(u => u.email === emailNormalizado)) {
      return { ok: false, erro: 'Já existe uma conta com este e-mail.' };
    }
    usuarios.push({ nome: nome.trim(), email: emailNormalizado, senhaHash: await this.hash(senha), perfil: 'cliente' });
    this.gravarUsuarios(usuarios);
    return { ok: true };
  }

  async entrar(email: string, senha: string): Promise<boolean> {
    await this.garantirContasDemo();
    const emailNormalizado = email.trim().toLowerCase();
    const senhaHash = await this.hash(senha);
    const usuario = this.lerUsuarios().find(u => u.email === emailNormalizado && u.senhaHash === senhaHash);
    if (!usuario) { return false; }
    const sessao: Sessao = { nome: usuario.nome, email: usuario.email, perfil: usuario.perfil ?? 'cliente' };
    this.sessao$.next(sessao);
    try { localStorage.setItem(CHAVE_SESSAO, JSON.stringify(sessao)); } catch { /* ignora */ }
    return true;
  }

  sair(): void {
    this.sessao$.next(null);
    try { localStorage.removeItem(CHAVE_SESSAO); } catch { /* ignora */ }
  }

  private async garantirContasDemo(): Promise<void> {
    const usuarios = this.lerUsuarios();
    const contas: { nome: string; conta: { email: string; senha: string }; perfil: Perfil }[] = [
      { nome: 'Cliente Demonstração', conta: this.contaDemo, perfil: 'cliente' },
      { nome: 'Administrador', conta: this.contaAdmin, perfil: 'admin' }
    ];
    let alterou = false;
    for (const c of contas) {
      if (!usuarios.some(u => u.email === c.conta.email)) {
        usuarios.push({ nome: c.nome, email: c.conta.email, senhaHash: await this.hash(c.conta.senha), perfil: c.perfil });
        alterou = true;
      }
    }
    if (alterou) { this.gravarUsuarios(usuarios); }
  }

  private async hash(texto: string): Promise<string> {
    const dados = new TextEncoder().encode('sportzone:' + texto);
    const buf = await crypto.subtle.digest('SHA-256', dados);
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
  }

  private lerUsuarios(): Usuario[] {
    try { return JSON.parse(localStorage.getItem(CHAVE_USUARIOS) ?? '[]') as Usuario[]; } catch { return []; }
  }

  private gravarUsuarios(lista: Usuario[]): void {
    try { localStorage.setItem(CHAVE_USUARIOS, JSON.stringify(lista)); } catch { /* ignora */ }
  }

  private lerSessao(): Sessao | null {
    try {
      const s = JSON.parse(localStorage.getItem(CHAVE_SESSAO) ?? 'null') as Partial<Sessao> | null;
      return s && s.email ? { nome: s.nome ?? '', email: s.email, perfil: s.perfil ?? 'cliente' } : null;
    } catch { return null; }
  }
}
