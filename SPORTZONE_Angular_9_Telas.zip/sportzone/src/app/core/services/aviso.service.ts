import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface Aviso { texto: string; tipo: 'ok' | 'erro'; }

/** Mensagem curta de feedback (toast) mostrada na parte de baixo da tela. */
@Injectable({ providedIn: 'root' })
export class AvisoService {
  private readonly aviso$ = new BehaviorSubject<Aviso | null>(null);
  readonly aviso = this.aviso$.asObservable();
  private temporizador?: ReturnType<typeof setTimeout>;

  mostrar(texto: string, tipo: 'ok' | 'erro' = 'ok'): void {
    this.aviso$.next({ texto, tipo });
    clearTimeout(this.temporizador);
    this.temporizador = setTimeout(() => this.aviso$.next(null), 3200);
  }
}
