import { Injectable } from '@angular/core';
import { BehaviorSubject, combineLatest, map } from 'rxjs';
import { ItemCarrinho, LinhaCarrinho, Produto } from '../models/produto';
import { ProdutosService } from './produtos.service';

const CHAVE = 'sz_carrinho_v2';
export const FRETE_GRATIS_A_PARTIR_DE = 299;
export const VALOR_FRETE = 24.9;

export interface ResultadoCarrinho { ok: boolean; mensagem: string; }

/** Carrinho local: guarda só id, tamanho e quantidade; preço e estoque vêm sempre do catálogo. */
@Injectable({ providedIn: 'root' })
export class CarrinhoService {
  private readonly linhas$ = new BehaviorSubject<LinhaCarrinho[]>(this.carregar());

  readonly itens$ = combineLatest([this.linhas$, this.produtosService.produtos$]).pipe(
    map(([linhas, produtos]) => linhas
      .map(l => ({ ...l, produto: produtos.find(p => p.id === l.id) }))
      .filter((i): i is ItemCarrinho => !!i.produto && i.produto.situacao === 'Ativo' && i.produto.estoque > 0)
      .map(i => ({ ...i, quantidade: Math.min(i.quantidade, i.produto.estoque) })))
  );
  readonly quantidadeTotal$ = this.itens$.pipe(map(l => l.reduce((s, i) => s + i.quantidade, 0)));
  readonly subtotal$ = this.itens$.pipe(map(l => l.reduce((s, i) => s + i.quantidade * i.produto.preco, 0)));
  readonly frete$ = this.subtotal$.pipe(map(s => (s === 0 || s >= FRETE_GRATIS_A_PARTIR_DE ? 0 : VALOR_FRETE)));
  readonly total$ = combineLatest([this.subtotal$, this.frete$]).pipe(map(([s, f]) => s + f));

  constructor(private produtosService: ProdutosService) {}

  adicionar(produto: Produto, quantidade = 1, tamanho: string | null = null): ResultadoCarrinho {
    if (produto.situacao !== 'Ativo' || produto.estoque < 1) {
      return { ok: false, mensagem: `“${produto.nome}” está indisponível.` };
    }
    const linhas = this.linhas$.value.map(l => ({ ...l }));
    const existente = linhas.find(l => l.id === produto.id && l.tamanho === tamanho);
    const jaNoCarrinho = linhas.filter(l => l.id === produto.id).reduce((s, l) => s + l.quantidade, 0);
    if (jaNoCarrinho + quantidade > produto.estoque) {
      return { ok: false, mensagem: `Quantidade máxima em estoque atingida para “${produto.nome}”.` };
    }
    if (existente) { existente.quantidade += quantidade; } else { linhas.push({ id: produto.id, tamanho, quantidade }); }
    this.salvar(linhas);
    return { ok: true, mensagem: `“${produto.nome}” foi adicionado ao carrinho.` };
  }

  alterarQuantidade(item: LinhaCarrinho, delta: number): void {
    const outras = this.linhas$.value.filter(l => l.id === item.id && l.tamanho !== item.tamanho).reduce((s, l) => s + l.quantidade, 0);
    const produto = this.produtosService.obter(item.id);
    const maximo = (produto?.estoque ?? 0) - outras;
    this.salvar(this.linhas$.value
      .map(l => (l.id === item.id && l.tamanho === item.tamanho ? { ...l, quantidade: Math.max(1, Math.min(maximo, l.quantidade + delta)) } : l)));
  }

  remover(item: LinhaCarrinho): void {
    this.salvar(this.linhas$.value.filter(l => !(l.id === item.id && l.tamanho === item.tamanho)));
  }

  limpar(): void { this.salvar([]); }

  private salvar(linhas: LinhaCarrinho[]): void {
    this.linhas$.next(linhas);
    try { localStorage.setItem(CHAVE, JSON.stringify(linhas)); } catch { /* armazenamento indisponível */ }
  }

  private carregar(): LinhaCarrinho[] {
    try {
      const l = JSON.parse(localStorage.getItem(CHAVE) ?? '[]') as LinhaCarrinho[];
      return Array.isArray(l) ? l : [];
    } catch { return []; }
  }
}
