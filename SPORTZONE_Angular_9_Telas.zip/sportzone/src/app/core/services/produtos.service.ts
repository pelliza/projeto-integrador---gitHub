import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Categoria, DadosProduto, Produto } from '../models/produto';

const CHAVE = 'sz_produtos_v2';

/** Imagens disponíveis para os produtos (ilustrações SVG da pasta assets/img). */
export const IMAGENS_PRODUTO: string[] = [
  'camisa-titular', 'camisa-treino', 'camisa-goleiro', 'chuteira-campo', 'chuteira-society', 'chuteira-futsal',
  'bola', 'bola-society', 'luvas-goleiro', 'caneleira', 'meiao', 'mochila'
].map(n => `assets/img/${n}.svg`);

const INICIAIS: Produto[] = [
  { id: 1, nome: 'Camisa Titular Verde 10', categoria: 'Camisas', preco: 249.9, estoque: 14, descricao: 'Tecido leve com secagem rápida, gola em V e acabamento reforçado.', imagem: 'assets/img/camisa-titular.svg', situacao: 'Ativo' },
  { id: 2, nome: 'Camisa Treino Black 07', categoria: 'Camisas', preco: 179.9, estoque: 22, descricao: 'Ideal para treinos e peladas, com tecido respirável.', imagem: 'assets/img/camisa-treino.svg', situacao: 'Ativo' },
  { id: 3, nome: 'Chuteira de Campo Velocity', categoria: 'Chuteiras', preco: 459.9, estoque: 9, descricao: 'Travas para gramado natural, ajuste firme e leve.', imagem: 'assets/img/chuteira-campo.svg', situacao: 'Ativo' },
  { id: 4, nome: 'Chuteira Society Street', categoria: 'Chuteiras', preco: 329.9, estoque: 12, descricao: 'Solado para grama sintética com tração multidirecional.', imagem: 'assets/img/chuteira-society.svg', situacao: 'Ativo' },
  { id: 5, nome: 'Bola de Campo Pro', categoria: 'Bolas', preco: 189.9, estoque: 30, descricao: 'Costura reforçada e tamanho oficial.', imagem: 'assets/img/bola.svg', situacao: 'Ativo' },
  { id: 6, nome: 'Luvas de Goleiro Guard', categoria: 'Goleiro', preco: 219.9, estoque: 6, descricao: 'Palma com alta aderência e punho ajustável.', imagem: 'assets/img/luvas-goleiro.svg', situacao: 'Ativo' },
  { id: 7, nome: 'Caneleira Shield', categoria: 'Acessórios', preco: 59.9, estoque: 40, descricao: 'Proteção leve e anatômica.', imagem: 'assets/img/caneleira.svg', situacao: 'Ativo' },
  { id: 8, nome: 'Mochila Esportiva SZ', categoria: 'Acessórios', preco: 139.9, estoque: 0, descricao: 'Compartimento ventilado para chuteiras.', imagem: 'assets/img/mochila.svg', situacao: 'Ativo' },
  { id: 9, nome: 'Meião Listrado Pro', categoria: 'Acessórios', preco: 39.9, estoque: 55, descricao: 'Cano alto com reforço no pé.', imagem: 'assets/img/meiao.svg', situacao: 'Ativo' },
  { id: 10, nome: 'Camisa Goleiro Neon 01', categoria: 'Goleiro', preco: 199.9, estoque: 8, descricao: 'Manga longa com ombreiras e tecido leve.', imagem: 'assets/img/camisa-goleiro.svg', situacao: 'Ativo' },
  { id: 11, nome: 'Bola Society Night', categoria: 'Bolas', preco: 149.9, estoque: 18, descricao: 'Miolo controlado para quadras e society.', imagem: 'assets/img/bola-society.svg', situacao: 'Ativo' },
  { id: 12, nome: 'Chuteira Futsal Court', categoria: 'Chuteiras', preco: 279.9, estoque: 4, descricao: 'Solado de borracha não marcante.', imagem: 'assets/img/chuteira-futsal.svg', situacao: 'Ativo' }
];

export interface FiltroCatalogo {
  categoria?: string | null;
  busca?: string | null;
  precoMax?: number | null;
  somenteEstoque?: boolean;
  ordem?: string | null;
}

/**
 * Catálogo de produtos (DEMONSTRATIVO).
 * Não há banco de dados: os produtos ficam no localStorage do navegador, o que permite
 * que as alterações feitas na área administrativa apareçam na loja.
 */
@Injectable({ providedIn: 'root' })
export class ProdutosService {
  readonly categorias: Categoria[] = ['Camisas', 'Chuteiras', 'Bolas', 'Goleiro', 'Acessórios'];

  private readonly lista$ = new BehaviorSubject<Produto[]>(this.carregar());
  readonly produtos$ = this.lista$.asObservable();

  get todos(): Produto[] { return this.lista$.value; }

  obter(id: number): Produto | undefined {
    return this.lista$.value.find(p => p.id === id);
  }

  /** Lista para a vitrine da loja: só produtos ativos, com filtros e ordenação. */
  listar(f: FiltroCatalogo = {}): Produto[] {
    const termo = (f.busca ?? '').trim().toLowerCase();
    const r = this.lista$.value.filter(p =>
      p.situacao === 'Ativo' &&
      (!f.categoria || p.categoria === f.categoria) &&
      (!termo || `${p.nome} ${p.categoria} ${p.descricao}`.toLowerCase().includes(termo)) &&
      (!f.precoMax || p.preco <= f.precoMax) &&
      (!f.somenteEstoque || p.estoque > 0));
    if (f.ordem === 'menor') { r.sort((a, b) => a.preco - b.preco); }
    if (f.ordem === 'maior') { r.sort((a, b) => b.preco - a.preco); }
    if (f.ordem === 'nome') { r.sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR')); }
    return r;
  }

  criar(dados: DadosProduto): Produto {
    const id = this.todos.reduce((m, p) => Math.max(m, p.id), 0) + 1;
    const novo: Produto = { id, ...dados };
    this.salvar([...this.todos, novo]);
    return novo;
  }

  atualizar(id: number, dados: Partial<DadosProduto>): boolean {
    if (!this.obter(id)) { return false; }
    this.salvar(this.todos.map(p => (p.id === id ? { ...p, ...dados } : p)));
    return true;
  }

  excluir(id: number): void {
    this.salvar(this.todos.filter(p => p.id !== id));
  }

  /** Tamanhos oferecidos para o produto (ou null quando não se aplica). */
  tamanhosDe(p: Produto): string[] | null {
    if (p.categoria === 'Chuteiras') { return ['37', '38', '39', '40', '41', '42', '43']; }
    if (p.categoria === 'Camisas' || (p.categoria === 'Goleiro' && /camisa/i.test(p.nome))) { return ['P', 'M', 'G', 'GG']; }
    if (p.categoria === 'Goleiro' && /luva/i.test(p.nome)) { return ['7', '8', '9', '10']; }
    return null;
  }

  private salvar(lista: Produto[]): void {
    this.lista$.next(lista);
    try { localStorage.setItem(CHAVE, JSON.stringify(lista)); } catch { /* armazenamento indisponível */ }
  }

  private carregar(): Produto[] {
    try {
      const bruto = localStorage.getItem(CHAVE);
      if (bruto) {
        const lista = JSON.parse(bruto) as Produto[];
        if (Array.isArray(lista)) { return lista; }
      }
    } catch { /* usa os dados iniciais */ }
    return INICIAIS.map(p => ({ ...p }));
  }
}
