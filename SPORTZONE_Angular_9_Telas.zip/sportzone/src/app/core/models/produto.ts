export type Categoria = 'Camisas' | 'Chuteiras' | 'Bolas' | 'Goleiro' | 'Acessórios';
export type SituacaoProduto = 'Ativo' | 'Inativo';

export interface Produto {
  id: number;
  nome: string;
  categoria: Categoria;
  preco: number;
  estoque: number;
  descricao: string;
  imagem: string;
  situacao: SituacaoProduto;
}

/** Dados que o administrador informa ao cadastrar/editar (o id é gerado pelo sistema). */
export type DadosProduto = Omit<Produto, 'id'>;

/** Item guardado no carrinho: só o id (e o tamanho); o produto é buscado no catálogo. */
export interface LinhaCarrinho {
  id: number;
  tamanho: string | null;
  quantidade: number;
}

/** Item do carrinho já combinado com os dados atuais do produto. */
export interface ItemCarrinho extends LinhaCarrinho {
  produto: Produto;
}

export type Perfil = 'cliente' | 'admin';

export interface Usuario {
  nome: string;
  email: string;
  senhaHash: string;
  perfil?: Perfil;
}

export interface Sessao {
  nome: string;
  email: string;
  perfil: Perfil;
}
