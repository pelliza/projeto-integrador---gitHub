import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

/** Só permite abrir a área administrativa com uma sessão de administrador (demonstrativo). */
export const adminGuard: CanActivateFn = (_route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  if (auth.ehAdmin) { return true; }
  return router.createUrlTree(['/login'], { queryParams: { acesso: 'admin', retorno: state.url } });
};
