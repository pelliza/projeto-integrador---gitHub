import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { combineLatest, map } from 'rxjs';
import { Produto } from '../core/models/produto';
import { AvisoService } from '../core/services/aviso.service';
import { CarrinhoService } from '../core/services/carrinho.service';
import { ProdutosService } from '../core/services/produtos.service';

/** TELA 4 — Catálogo de produtos com filtros, pesquisa e ordenação (estado guardado na URL). */
@Component({
  selector: 'app-catalogo',
  templateUrl: './catalogo.component.html',
  styleUrls: ['./catalogo.component.css']
})
export class CatalogoComponent {
  categorias = this.produtosService.categorias;
  faixasPreco = [
    { valor: 0, texto: 'Qualquer valor' },
    { valor: 100, texto: 'Até R$ 100' },
    { valor: 250, texto: 'Até R$ 250' },
    { valor: 500, texto: 'Até R$ 500' }
  ];

  vm$ = combineLatest([this.route.queryParamMap, this.produtosService.produtos$]).pipe(
    map(([q]) => {
      const f = {
        categoria: q.get('categoria'),
        busca: q.get('q'),
        precoMax: Number(q.get('max')) || 0,
        somenteEstoque: q.get('disp') === '1',
        ordem: q.get('ord') || 'rel'
      };
      return { f, produtos: this.produtosService.listar(f) };
    })
  );

  constructor(
    private produtosService: ProdutosService,
    private carrinho: CarrinhoService,
    private aviso: AvisoService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  /** Atualiza um filtro na URL; valores vazios removem o parâmetro. */
  filtrar(chave: 'categoria' | 'max' | 'disp' | 'ord', valor: string | number | boolean | null): void {
    const v = valor === '' || valor === 0 || valor === false || valor === 'rel' ? null : String(valor === true ? '1' : valor);
    this.router.navigate([], { relativeTo: this.route, queryParams: { [chave]: v }, queryParamsHandling: 'merge' });
  }

  adicionar(produto: Produto): void {
    const r = this.carrinho.adicionar(produto);
    this.aviso.mostrar(r.mensagem, r.ok ? 'ok' : 'erro');
  }
}
