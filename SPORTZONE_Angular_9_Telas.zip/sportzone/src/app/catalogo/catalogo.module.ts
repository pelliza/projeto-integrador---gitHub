import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { CatalogoComponent } from './catalogo.component';

const routes: Routes = [{ path: '', component: CatalogoComponent, title: 'SPORTZONE | Catálogo' }];

/** TELA 4 — Catálogo de produtos (rota /catalogo, carregada sob demanda). */
@NgModule({
  declarations: [CatalogoComponent],
  imports: [SharedModule, RouterModule.forChild(routes)]
})
export class CatalogoModule {}
