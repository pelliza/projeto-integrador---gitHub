import { Component } from '@angular/core';
import { map } from 'rxjs';
import { ProdutosService } from '../../core/services/produtos.service';

/** TELA 7 — Área administrativa: indicadores do catálogo, alertas de estoque e atalhos. */
@Component({
  selector: 'app-painel',
  templateUrl: './painel.component.html',
  styleUrls: ['./painel.component.css']
})
export class PainelComponent {
  vm$ = this.produtosService.produtos$.pipe(
    map(lista => {
      const baixo = lista.filter(p => p.estoque > 0 && p.estoque <= 6);
      const esgotados = lista.filter(p => p.estoque === 0);
      return {
        total: lista.length,
        valorEstoque: lista.reduce((s, p) => s + p.preco * p.estoque, 0),
        baixo: baixo.length,
        esgotados: esgotados.length,
        alertas: [...baixo, ...esgotados]
      };
    })
  );

  constructor(private produtosService: ProdutosService) {}
}
