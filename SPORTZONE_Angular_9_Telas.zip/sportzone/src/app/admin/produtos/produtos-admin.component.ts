import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';
import { combineLatest, map, startWith } from 'rxjs';
import { Produto } from '../../core/models/produto';
import { AvisoService } from '../../core/services/aviso.service';
import { ProdutosService } from '../../core/services/produtos.service';

/** TELA 8 — Gerenciamento de produtos: busca, atualização de preço/estoque, edição e exclusão. */
@Component({
  selector: 'app-produtos-admin',
  templateUrl: './produtos-admin.component.html',
  styleUrls: ['./produtos-admin.component.css']
})
export class ProdutosAdminComponent {
  categorias = this.produtosService.categorias;
  busca = new FormControl('', { nonNullable: true });
  categoria = new FormControl('', { nonNullable: true });

  vm$ = combineLatest([
    this.produtosService.produtos$,
    this.busca.valueChanges.pipe(startWith('')),
    this.categoria.valueChanges.pipe(startWith(''))
  ]).pipe(
    map(([lista, b, c]) => {
      const termo = b.trim().toLowerCase();
      return {
        total: lista.length,
        produtos: lista.filter(p => (!c || p.categoria === c) && (!termo || `${p.nome} ${p.categoria}`.toLowerCase().includes(termo)))
      };
    })
  );

  constructor(private produtosService: ProdutosService, private aviso: AvisoService) {}

  situacao(p: Produto): { texto: string; classe: string } {
    if (p.situacao === 'Inativo') { return { texto: 'Inativo', classe: 'off' }; }
    if (p.estoque === 0) { return { texto: 'Esgotado', classe: 'out' }; }
    return p.estoque <= 6 ? { texto: 'Estoque baixo', classe: 'low' } : { texto: 'Disponível', classe: 'ok' };
  }

  salvar(p: Produto, precoTxt: string, estoqueTxt: string): void {
    const preco = Number(precoTxt.replace(',', '.'));
    const estoque = Number(estoqueTxt);
    if (precoTxt.trim() === '' || !(preco > 0) || estoqueTxt.trim() === '' || !Number.isInteger(estoque) || estoque < 0) {
      this.aviso.mostrar('Informe um preço maior que zero e um estoque inteiro (0 ou mais).', 'erro');
      return;
    }
    this.produtosService.atualizar(p.id, { preco, estoque });
    this.aviso.mostrar(`“${p.nome}” atualizado.`);
  }

  excluir(p: Produto): void {
    if (confirm(`Excluir “${p.nome}” do catálogo?`)) {
      this.produtosService.excluir(p.id);
      this.aviso.mostrar('Produto excluído.');
    }
  }

  porId(_i: number, p: Produto): number { return p.id; }
}
