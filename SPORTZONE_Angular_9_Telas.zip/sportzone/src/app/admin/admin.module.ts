import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { AdminShellComponent } from './shell/admin-shell.component';
import { PainelComponent } from './painel/painel.component';
import { ProdutoFormComponent } from './produto-form/produto-form.component';
import { ProdutosAdminComponent } from './produtos/produtos-admin.component';

const routes: Routes = [
  {
    path: '',
    component: AdminShellComponent,
    children: [
      { path: '', component: PainelComponent, title: 'SPORTZONE | Painel administrativo' },
      { path: 'produtos', component: ProdutosAdminComponent, title: 'SPORTZONE | Gerenciar produtos' },
      { path: 'produtos/novo', component: ProdutoFormComponent, title: 'SPORTZONE | Cadastrar produto' },
      { path: 'produtos/editar/:id', component: ProdutoFormComponent, title: 'SPORTZONE | Editar produto' }
    ]
  }
];

/**
 * MÓDULO ADMINISTRATIVO (carregado sob demanda e protegido pelo adminGuard):
 *  Tela 7 — Área administrativa (PainelComponent)
 *  Tela 8 — Gerenciamento de produtos (ProdutosAdminComponent)
 *  Tela 9 — Cadastro e edição de produtos (ProdutoFormComponent)
 */
@NgModule({
  declarations: [AdminShellComponent, PainelComponent, ProdutosAdminComponent, ProdutoFormComponent],
  imports: [SharedModule, ReactiveFormsModule, RouterModule.forChild(routes)]
})
export class AdminModule {}
