import { Component } from '@angular/core';

/** Barra de navegação da administração, comum às telas 7, 8 e 9. */
@Component({
  selector: 'app-admin-shell',
  template: `
    <div class="admin-bar">
      <div class="container">
        <span class="tag-adm">Admin</span>
        <a routerLink="/admin" routerLinkActive="ativo" [routerLinkActiveOptions]="{ exact: true }">Painel</a>
        <a routerLink="/admin/produtos" routerLinkActive="ativo" [routerLinkActiveOptions]="{ exact: true }">Produtos</a>
        <a routerLink="/admin/produtos/novo" routerLinkActive="ativo">Novo produto</a>
        <a routerLink="/" class="loja">Ver loja ↗</a>
      </div>
    </div>
    <router-outlet></router-outlet>
  `,
  styles: [`
    .admin-bar{background:var(--sz-ink-2);color:#fff}
    .container{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
    .tag-adm{background:var(--sz-lime);color:#04210f;font-size:.7rem;font-weight:900;text-transform:uppercase;padding:3px 9px;border-radius:999px;margin-right:10px}
    a{color:#c9d3cd;text-decoration:none;font-weight:600;font-size:.9rem;padding:13px 14px;border-bottom:3px solid transparent}
    a:hover{color:#fff}a.ativo{color:#fff;border-bottom-color:var(--sz-lime)}
    .loja{margin-left:auto}
  `]
})
export class AdminShellComponent {}
