import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { defer, map, startWith } from 'rxjs';
import { Categoria, DadosProduto, Produto, SituacaoProduto } from '../../core/models/produto';
import { AvisoService } from '../../core/services/aviso.service';
import { IMAGENS_PRODUTO, ProdutosService } from '../../core/services/produtos.service';

/** TELA 9 — Cadastro e edição de produtos (a mesma tela atende os dois casos). */
@Component({
  selector: 'app-produto-form',
  templateUrl: './produto-form.component.html',
  styleUrls: ['./produto-form.component.css']
})
export class ProdutoFormComponent {
  categorias = this.produtosService.categorias;
  imagens = IMAGENS_PRODUTO;
  editando: Produto | null = null;
  enviado = false;

  form = this.fb.group({
    nome: ['', [Validators.required, Validators.minLength(3)]],
    categoria: ['' as Categoria | '', [Validators.required]],
    situacao: ['Ativo' as SituacaoProduto],
    preco: [null as number | null, [Validators.required, Validators.min(0.01)]],
    estoque: [null as number | null, [Validators.required, Validators.min(0), Validators.pattern(/^\d+$/)]],
    descricao: ['', [Validators.required, Validators.minLength(10)]],
    imagem: [IMAGENS_PRODUTO[6], [Validators.required]]
  });

  /** Produto montado com o que está digitado, para a pré-visualização do card. */
  previa$ = defer(() => this.form.valueChanges.pipe(
    startWith(this.form.getRawValue()),
    map(v => ({
      nome: v.nome || 'Nome do produto',
      categoria: (v.categoria || 'Categoria') as Categoria,
      preco: Number(v.preco) || 0,
      estoque: Number(v.estoque) || 0,
      descricao: v.descricao || 'Descrição do produto.',
      imagem: v.imagem || IMAGENS_PRODUTO[6],
      situacao: (v.situacao || 'Ativo') as SituacaoProduto
    }))
  ));

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private produtosService: ProdutosService,
    private aviso: AvisoService
  ) {
    const id = this.route.snapshot.paramMap.get('id');
    if (id !== null) {
      const produto = this.produtosService.obter(Number(id));
      if (!produto) {
        this.aviso.mostrar('Produto não encontrado.', 'erro');
        this.router.navigate(['/admin/produtos']);
        return;
      }
      this.editando = produto;
      this.form.patchValue(produto);
    }
  }

  get f() { return this.form.controls; }

  invalido(c: { invalid: boolean; touched: boolean }): boolean {
    return c.invalid && (c.touched || this.enviado);
  }

  escolherImagem(src: string): void { this.f.imagem.setValue(src); }

  salvar(): void {
    this.enviado = true;
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();
    const dados: DadosProduto = {
      nome: (v.nome ?? '').trim(),
      categoria: v.categoria as Categoria,
      situacao: v.situacao ?? 'Ativo',
      preco: Number(v.preco),
      estoque: Number(v.estoque),
      descricao: (v.descricao ?? '').trim(),
      imagem: v.imagem ?? IMAGENS_PRODUTO[6]
    };
    if (this.editando) {
      this.produtosService.atualizar(this.editando.id, dados);
      this.aviso.mostrar('Produto atualizado com sucesso.');
    } else {
      this.produtosService.criar(dados);
      this.aviso.mostrar('Produto cadastrado com sucesso.');
    }
    this.router.navigate(['/admin/produtos']);
  }

  excluir(): void {
    if (this.editando && confirm(`Excluir “${this.editando.nome}” do catálogo?`)) {
      this.produtosService.excluir(this.editando.id);
      this.aviso.mostrar('Produto excluído.');
      this.router.navigate(['/admin/produtos']);
    }
  }
}
