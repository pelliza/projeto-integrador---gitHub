import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { combineLatest, map, tap } from 'rxjs';
import { Produto } from '../core/models/produto';
import { AvisoService } from '../core/services/aviso.service';
import { CarrinhoService } from '../core/services/carrinho.service';
import { ProdutosService } from '../core/services/produtos.service';

/** TELA 5 — Detalhes do produto: informações, tamanho, quantidade e adição ao carrinho. */
@Component({
  selector: 'app-detalhe-produto',
  templateUrl: './detalhe-produto.component.html',
  styleUrls: ['./detalhe-produto.component.css']
})
export class DetalheProdutoComponent {
  tamanho: string | null = null;
  quantidade = 1;

  vm$ = combineLatest([this.route.paramMap, this.produtosService.produtos$]).pipe(
    map(([params]) => {
      const produto = this.produtosService.obter(Number(params.get('id')));
      const visivel = produto && produto.situacao === 'Ativo' ? produto : undefined;
      return {
        produto: visivel,
        tamanhos: visivel ? this.produtosService.tamanhosDe(visivel) : null,
        relacionados: visivel ? this.relacionados(visivel) : []
      };
    }),
    tap(vm => {
      if (vm.produto) {
        this.quantidade = Math.max(1, Math.min(this.quantidade, vm.produto.estoque || 1));
        if (vm.tamanhos && !vm.tamanhos.includes(this.tamanho ?? '')) { this.tamanho = vm.tamanhos[Math.min(1, vm.tamanhos.length - 1)]; }
        if (!vm.tamanhos) { this.tamanho = null; }
      }
    })
  );

  constructor(
    private route: ActivatedRoute,
    private produtosService: ProdutosService,
    private carrinho: CarrinhoService,
    private aviso: AvisoService
  ) {}

  private relacionados(p: Produto): Produto[] {
    const todos = this.produtosService.listar().filter(x => x.id !== p.id);
    return [...todos.filter(x => x.categoria === p.categoria), ...todos.filter(x => x.categoria !== p.categoria)].slice(0, 4);
  }

  alterarQuantidade(p: Produto, delta: number): void {
    this.quantidade = Math.max(1, Math.min(p.estoque, this.quantidade + delta));
  }

  adicionar(p: Produto): void {
    const r = this.carrinho.adicionar(p, this.quantidade, this.tamanho);
    this.aviso.mostrar(r.mensagem, r.ok ? 'ok' : 'erro');
    if (r.ok) { this.quantidade = 1; }
  }

  adicionarRelacionado(p: Produto): void {
    const r = this.carrinho.adicionar(p, 1, this.produtosService.tamanhosDe(p)?.[1] ?? null);
    this.aviso.mostrar(r.mensagem, r.ok ? 'ok' : 'erro');
  }
}
