import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { DetalheProdutoComponent } from './detalhe-produto.component';

const routes: Routes = [{ path: ':id', component: DetalheProdutoComponent, title: 'SPORTZONE | Detalhes do produto' }];

/** TELA 5 — Detalhes do produto (rota /produto/:id, carregada sob demanda). */
@NgModule({
  declarations: [DetalheProdutoComponent],
  imports: [SharedModule, RouterModule.forChild(routes)]
})
export class ProdutoModule {}
