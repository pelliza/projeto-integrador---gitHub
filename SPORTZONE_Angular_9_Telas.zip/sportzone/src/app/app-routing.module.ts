import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { adminGuard } from './core/guards/admin.guard';
import { HomeComponent } from './pages/home/home.component';

/**
 * As 9 telas do SPORTZONE:
 *  1 Login                       /login
 *  2 Cadastro de usuário         /registro
 *  3 Página inicial              /
 *  4 Catálogo de produtos        /catalogo
 *  5 Detalhes do produto         /produto/:id
 *  6 Carrinho de compras         /carrinho
 *  7 Área administrativa         /admin
 *  8 Gerenciamento de produtos   /admin/produtos
 *  9 Cadastro e edição de produtos  /admin/produtos/novo  e  /admin/produtos/editar/:id
 */
const routes: Routes = [
  { path: '', component: HomeComponent, title: 'SPORTZONE | Início' },
  { path: 'login', loadChildren: () => import('./login/login.module').then(m => m.LoginModule) },
  { path: 'registro', loadChildren: () => import('./registro/registro.module').then(m => m.RegistroModule) },
  { path: 'catalogo', loadChildren: () => import('./catalogo/catalogo.module').then(m => m.CatalogoModule) },
  { path: 'produto', loadChildren: () => import('./produto/produto.module').then(m => m.ProdutoModule) },
  { path: 'carrinho', loadChildren: () => import('./carrinho/carrinho.module').then(m => m.CarrinhoModule) },
  {
    path: 'admin',
    canActivate: [adminGuard],
    loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule)
  },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      scrollPositionRestoration: 'enabled',
      anchorScrolling: 'enabled'
    })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
