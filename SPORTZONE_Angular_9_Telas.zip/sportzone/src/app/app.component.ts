import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <app-header></app-header>
    <main id="conteudo">
      <router-outlet></router-outlet>
    </main>
    <app-footer></app-footer>
    <app-aviso></app-aviso>
  `
})
export class AppComponent {}
