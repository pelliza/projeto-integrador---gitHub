import { Component } from '@angular/core';
import { map } from 'rxjs';
import { CarrinhoService } from '../../core/services/carrinho.service';
import { AvisoService } from '../../core/services/aviso.service';
import { Produto } from '../../core/models/produto';
import { ProdutosService } from '../../core/services/produtos.service';

/** TELA 3 — Página inicial: destaque, benefícios, categorias e produtos em destaque. */
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  categorias = this.produtosService.categorias;
  destaques$ = this.produtosService.produtos$.pipe(
    map(() => this.produtosService.listar().filter(p => p.estoque > 0).slice(0, 4))
  );

  constructor(
    private produtosService: ProdutosService,
    private carrinho: CarrinhoService,
    private aviso: AvisoService
  ) {}

  adicionar(produto: Produto): void {
    const r = this.carrinho.adicionar(produto);
    this.aviso.mostrar(r.mensagem, r.ok ? 'ok' : 'erro');
  }
}
