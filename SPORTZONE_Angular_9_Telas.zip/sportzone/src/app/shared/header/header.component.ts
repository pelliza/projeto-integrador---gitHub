import { Component, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { CarrinhoService } from '../../core/services/carrinho.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  menuAberto = false;
  readonly sessao$ = this.auth.sessao;
  readonly quantidade$ = this.carrinho.quantidadeTotal$;

  constructor(private auth: AuthService, private carrinho: CarrinhoService, private router: Router) {}

  buscar(termo: string): void {
    this.menuAberto = false;
    this.router.navigate(['/catalogo'], { queryParams: { q: termo.trim() || null } });
  }

  sair(): void {
    this.auth.sair();
    this.menuAberto = false;
    this.router.navigate(['/']);
  }

  @HostListener('document:keydown.escape')
  fechar(): void { this.menuAberto = false; }
}
