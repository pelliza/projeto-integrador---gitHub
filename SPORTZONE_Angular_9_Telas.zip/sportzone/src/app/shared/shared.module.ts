import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AvisoComponent } from './aviso/aviso.component';
import { ProdutoCardComponent } from './produto-card/produto-card.component';

/** Peças reutilizadas em várias telas: card de produto e aviso (toast). */
@NgModule({
  declarations: [ProdutoCardComponent, AvisoComponent],
  imports: [CommonModule, RouterModule],
  exports: [CommonModule, RouterModule, ProdutoCardComponent, AvisoComponent]
})
export class SharedModule {}
