import { Component } from '@angular/core';
import { AvisoService } from '../../core/services/aviso.service';

@Component({
  selector: 'app-aviso',
  template: `<div class="toast" *ngIf="aviso.aviso | async as a" [class.erro]="a.tipo === 'erro'" role="status" aria-live="polite">{{ a.texto }}</div>`,
  styles: [`
    .toast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);max-width:calc(100% - 32px);background:var(--sz-black);color:#fff;padding:12px 20px;border-radius:999px;font-weight:600;z-index:200;box-shadow:var(--shadow);text-align:center}
    .toast.erro{background:var(--sz-red)}
  `]
})
export class AvisoComponent {
  constructor(public aviso: AvisoService) {}
}
