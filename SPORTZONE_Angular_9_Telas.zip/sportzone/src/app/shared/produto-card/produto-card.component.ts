import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Produto } from '../../core/models/produto';

/** Card de produto usado na página inicial, no catálogo, nos detalhes e na pré-visualização do admin. */
@Component({
  selector: 'app-produto-card',
  templateUrl: './produto-card.component.html',
  styleUrls: ['./produto-card.component.css']
})
export class ProdutoCardComponent {
  @Input({ required: true }) produto!: Produto | Omit<Produto, 'id'>;
  /** Quando true, mostra o card sem botões (usado na pré-visualização do cadastro). */
  @Input() somenteVisual = false;
  @Output() adicionar = new EventEmitter<Produto>();

  get id(): number | null { return 'id' in this.produto ? this.produto.id : null; }
  get esgotado(): boolean { return this.produto.estoque <= 0; }
  get ultimas(): boolean { return this.produto.estoque > 0 && this.produto.estoque <= 6; }

  clicarAdicionar(): void {
    if ('id' in this.produto) { this.adicionar.emit(this.produto); }
  }
}
